# GOAL7
GOAL7 - A futsal booking platform A web application for managing futsal court bookings, allowing admins to oversee the platform, futsal clients to manage their venues, and customers to easily book available futsal slots.
