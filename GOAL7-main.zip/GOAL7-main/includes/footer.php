</section>  
    <!-- Footer -->
    <footer class="bg-yellow-500 shadow-md bottom-0 w-full mt-16">
        <div class="max-w-screen-xl mx-auto px-6 py-4 text-center">
            <p>&copy; 2024 Futsal Booking Platform. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
