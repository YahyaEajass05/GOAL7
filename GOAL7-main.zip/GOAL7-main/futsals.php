<?php include('./includes/header.php'); ?>


<?php include('./includes/nav.php'); ?>


<!-- Main Content -->
<main class="max-w-screen-xl mx-auto mt-8 px-6 hidden" id="page-content-main">
    <?php include('./index/futsal_posts.php'); ?>
</main>

<?php include('./includes/footer.php'); ?>

